(function(){
const $=id=>document.getElementById(id);
// ---- Tema 2: salto
const c2=$("c2"),x2=c2.getContext("2d");let anim=null;
function draw2(tp){const v0=+$("s2v").value,g=+$("s2g").value;$("o2v").textContent=v0;$("o2g").textContent=g;
 const T=2*v0/g,h=v0*v0/(2*g),W=c2.width,H=c2.height,sx=(W-60)/Math.max(T,.5),sy=(H-50)/Math.max(h,1)*.9;
 x2.clearRect(0,0,W,H);x2.strokeStyle="#c9d6ee";x2.lineWidth=1;for(let i=0;i<=10;i++){x2.beginPath();x2.moveTo(30+i*(W-60)/10,10);x2.lineTo(30+i*(W-60)/10,H-30);x2.stroke()}
 x2.strokeStyle="#1b2a4a";x2.beginPath();x2.moveTo(30,H-30);x2.lineTo(W-30,H-30);x2.stroke();
 x2.strokeStyle="#e8710a";x2.lineWidth=3;x2.beginPath();for(let i=0;i<=100;i++){const t=T*i/100,y=v0*t-.5*g*t*t;x2.lineTo(30+t*sx,H-30-y*sy)}x2.stroke();
 if(tp!=null){const t=Math.min(tp,T),y=v0*t-.5*g*t*t;x2.fillStyle="#c74440";x2.beginPath();x2.arc(30+t*sx,H-30-y*sy,9,0,7);x2.fill()}
 $("r2").innerHTML=`Altura máxima h = v₀²/2g = <b>${h.toFixed(2)} m</b> · tiempo en el aire 2v₀/g = <b>${T.toFixed(2)} s</b> · g equivale a <b>${(g/9.81).toFixed(2)}</b> veces la terrestre`}
function jump(){cancelAnimationFrame(anim);const T=2*$("s2v").value/$("s2g").value,t0=performance.now();
 (function f(n){const t=(n-t0)/1000;draw2(t);if(t<T)anim=requestAnimationFrame(f)})(t0)}
$("s2v").oninput=$("s2g").oninput=()=>draw2();$("b2").onclick=jump;draw2();
// ---- Tema 7: restitución
const c7=$("c7"),x7=c7.getContext("2d");let a7=null;
function run7(){cancelAnimationFrame(a7);const e=+$("s7").value;$("o7").textContent=e.toFixed(2);const g=9.81,W=c7.width,H=c7.height,h0=2;
 let y=h0,v=0,t=0,last=performance.now(),n=0,hist=[],resting=false;
 function info(){$("r7").innerHTML=`Rebotes: <b>${n}</b> · altura del próximo rebote hₙ = e²ⁿ·h₀ = <b>${(h0*Math.pow(e,2*(n+1))).toFixed(3)} m</b> · energía perdida por rebote = <b>${((1-e*e)*100).toFixed(0)} %</b> ${e>=1?"· ¡nunca se detiene!":e==0?"· se pega al suelo":""}`}
 (function f(now){const dt=Math.min((now-last)/1000,.03);last=now;
  if(!resting){const sub=10;for(let i=0;i<sub;i++){const d=dt/sub;v-=g*d;y+=v*d;if(y<=0){y=0;if(Math.abs(v)<.4||e==0){v=0;resting=true}else{v=-e*v;n++}}}}
  t+=dt;hist.push([t,y]);if(hist.length>1500)hist.shift();
  x7.clearRect(0,0,W,H);x7.strokeStyle="#c9d6ee";for(let i=0;i<=8;i++){x7.beginPath();x7.moveTo(30,H-30-i*(H-50)/8);x7.lineTo(W-30,H-30-i*(H-50)/8);x7.stroke()}
  x7.strokeStyle="#1b2a4a";x7.lineWidth=2;x7.beginPath();x7.moveTo(30,H-30);x7.lineTo(W-30,H-30);x7.stroke();
  const sy=(H-60)/h0;x7.strokeStyle="#c2185b";x7.lineWidth=2;x7.beginPath();const t0=hist[0][0];hist.forEach(([tt,yy],i)=>{const px=30+((tt-t0)/10)*(W-60)*Math.min(1,10/Math.max(tt-t0,10))*1;x7.lineTo(px,H-30-yy*sy)});x7.stroke();
  x7.fillStyle="#c2185b";x7.beginPath();x7.arc(W-40,H-30-y*sy-10,10,0,7);x7.fill();info();
  if(!(resting&&hist.length>2)||true)a7=requestAnimationFrame(f)})(last)}
$("s7").oninput=run7;$("b7").onclick=run7;run7();
})();
