# Portafolio de Evidencias – Avance 2 · Física I (FUN-18)
Luis Alejandro Navarro Rojas · Universidad CENFOTEC · 2026-C3

Sitio estático de una sola página (`index.html`) con las 9 entradas del portafolio: ecuaciones (KaTeX), gráficas propias y dos simulaciones interactivas (temas 2 y 7).
Ver en línea: activar GitHub Pages en *Settings → Pages → Branch: main / root*.
